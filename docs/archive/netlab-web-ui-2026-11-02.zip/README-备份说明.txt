Netlab 原 Web 界面备份（2026-11-02）
=====================================

备份原因：netlab 显示层已迁移到 Qt 原生界面（R33 / D74），用户决定把原 web 前端
打包留档后从本地删除。

包含：
  netlab/static/index.html        原单页骨架（544 行）
  netlab/static/app.js            原前端逻辑（12,550 行）
  netlab/static/style.css         原主题与布局（2,118 行）
  netlab/static/desktop-shim.js   pywebview 桥接垫片
  netlab/desktop/webview_app.py   旧 pywebview + WebView2 桌面壳
  netlab/desktop/webview_bridge.py 旧壳的 js_api 桥

如何恢复查看（任选其一）：
  1) git 分支：git checkout backup/web-ui-static-2026-11-02
  2) 解压本 zip 到 NetlabHome/ 覆盖同名路径，然后 python -m netlab.desktop --web
     需要 netlab/server.py 里重新挂载 /static（见 QT_NATIVE_SPEC.md 变更记录 v1.3）
